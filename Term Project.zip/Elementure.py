# 15-112 - Summer 1
######################################
# Full name: Lewis Li
# Andrew ID: jieming1
# Section:  B
# Term Project: Elementure
######################################

from tkinter import *
from random import *
from copy import *
from math import *
import winsound
import string

#################
# Splash Screen #
#################

def initSplash(data):
	data.mode='splash'
	data.buttonWid,data.buttonHeight,data.margin=130,30,25
	data.startRx0=data.Width/2-data.buttonWid/2
	data.startRy0=data.Height*3/4-data.buttonHeight
	data.startRx1=data.startRx0+data.buttonWid
	data.startRy1=data.startRy0+data.buttonHeight
	data.helpRx0,data.helpRx1=data.startRx0,data.startRx1
	data.helpRy0=data.startRy0+data.buttonHeight+data.margin
	data.helpRy1=data.helpRy0+data.buttonHeight
	data.intrFont=('Helvetica',15)
	data.atomRadSplash,data.splashTime=10,0
	data.easyShield=[[-60,180,60],[60,60,60]]
	data.medShield,data.hardShield=[[-45,135],[90,90]],[[0],[90]]
	data.insaneShield=deepcopy(data.medShield)
	data.saberShield,data.fullShield=[[0],[1.5]],[[0],[359]]
	data.startColor=data.helpColor=data.luckColor=data.scoreColor='white'
	data.fullColor='#%02x%02x%02x' %(255,94,250)


def drawAtomSplash(canvas,data):
	canvas.create_oval(data.atomCx-data.atomRadSplash,
		data.atomCy-data.atomRadSplash,data.atomCx+data.atomRadSplash,
		data.atomCy+data.atomRadSplash,fill=data.atomColor,
		outline=data.atomColor)


def drawShieldSplash(canvas,data):
	for i in range(len(data.medShield[0])):
		canvas.create_arc(data.Width/2-data.shieldRad,
			data.Height/2-data.shieldRad,data.Width/2+data.shieldRad,
			data.Height/2+data.shieldRad,outline=data.atomColor,style=ARC,
			start=data.medShield[0][i],extent=data.medShield[1][i])


def drawSplash(canvas,data):
	drawBackground(canvas,data)
	drawAtomSplash(canvas,data)
	drawShieldSplash(canvas,data)
	# start
	titleText,titleFont='Elementure',('Helvetica',35,'bold')
	x0,y0=data.Width/2,150
	canvas.create_text(x0,y0,text=titleText,font=titleFont,
		anchor='center',fill='white')
	startText,intrFont='Start',data.intrFont
	x0,y0=data.Width/2,data.startRy0+data.buttonHeight/2
	canvas.create_text(x0,y0,text=startText,font=intrFont,
		fill=data.startColor)
	canvas.create_rectangle(data.startRx0,data.startRy0,
		data.startRx1,data.startRy1,width=2,outline=data.startColor)
	# help
	x0=data.helpRx0+data.buttonWid/2
	y0=data.helpRy0+data.buttonHeight/2
	canvas.create_text(x0,y0,text='Help',font=intrFont,fill=data.helpColor)
	canvas.create_rectangle(data.helpRx0,data.helpRy0,
		data.helpRx1,data.helpRy1,width=2,outline=data.helpColor)


def timerFiredSplash(data):
	data.splashTime+=1
	if data.splashTime%30==0: data.atomRadSplash=20
	if data.splashTime%50==0: 
		data.atomRadSplash=data.shieldRad
		data.splashTime=0
	else: data.atomRadSplash-=0.3
	

def mousePressedSplash(event,data):
	if(data.startRx0<=event.x<=data.startRx1 and
		data.startRy0<=event.y<=data.startRy1):
		data.mode='level'
	if(data.helpRx0<=event.x<=data.helpRx1 and
		data.helpRy0<=event.y<=data.helpRy1):
		data.mode='help'


def mouseMotionSplash(event,data):
	if(data.startRx0<=event.x<=data.startRx1 and
		data.startRy0<=event.y<=data.startRy1):
		data.startColor=data.atomColor
	elif(data.helpRx0<=event.x<=data.helpRx1 and
		data.helpRy0<=event.y<=data.helpRy1):
		data.helpColor=data.atomColor
	else: data.startColor=data.helpColor='white'


####################
# Help Intructions #
####################

def initHelp(data):
	data.atomCxHelp1,data.atomCxHelp2=data.Width/4,data.Width*3/4
	data.atomCyHelp=data.Height/2
	data.atomRadHelp=20
	data.shieldHelp1=deepcopy(data.easyShield)
	data.shieldHelp2=deepcopy(data.easyShield)
	data.backRx0,data.backRy0=100-data.buttonWid/2,50-data.buttonHeight/2
	data.backRx1=data.backRx0+data.buttonWid
	data.backRy1=data.backRy0+data.buttonHeight
	data.backColor='white'


def drawButtonHelp(canvas,data):
	canvas.create_text(data.backRx0+data.buttonWid/2,
		data.backRy0+data.buttonHeight/2,text='Back',font=data.intrFont,
		fill=data.backColor)
	canvas.create_rectangle(data.backRx0,data.backRy0,data.backRx1,
		data.backRy1,width=2,outline=data.backColor)


def drawAtomHelp(canvas,data):
	canvas.create_oval(data.atomCxHelp1-data.atomRadHelp,
		data.atomCy-data.atomRadHelp,data.atomCxHelp1+data.atomRadHelp,
		data.atomCy+data.atomRadHelp,fill=data.atomColor,
		outline=data.atomColor)
	canvas.create_oval(data.atomCxHelp2-data.atomRadHelp,
		data.atomCy-data.atomRadHelp,data.atomCxHelp2+data.atomRadHelp,
		data.atomCy+data.atomRadHelp,fill=data.atomColor,
		outline=data.atomColor)
	x0,y0=data.atomCxHelp1,data.atomCyHelp+data.atomRadHelp+data.margin*2


def drawShieldHelp(canvas,data):
	for i in range(len(data.shieldHelp1[0])):
		x0,y0=data.atomCxHelp1-data.shieldRad,data.atomCyHelp-data.shieldRad
		x1,y1=data.atomCxHelp1+data.shieldRad,data.atomCyHelp+data.shieldRad
		canvas.create_arc(x0,y0,x1,y1,start=data.shieldHelp1[0][i],
			extent=data.shieldHelp1[1][i],style=ARC,outline='cyan')
	for i in range(len(data.shieldHelp2[0])):
		x0,y0=data.atomCxHelp2-data.shieldRad,data.atomCyHelp-data.shieldRad
		x1,y1=data.atomCxHelp2+data.shieldRad,data.atomCyHelp+data.shieldRad
		canvas.create_arc(x0,y0,x1,y1,start=data.shieldHelp2[0][i],
			extent=data.shieldHelp2[1][i],style=ARC,outline='cyan')


def drawElectronHelp(canvas,data):
	eYHelp=data.Height/4
	canvas.create_oval(data.atomCxHelp1-data.eRad,eYHelp-data.eRad,
		data.atomCxHelp1+data.eRad,eYHelp+data.eRad,fill='cyan',
		outline='cyan')
	canvas.create_oval(data.atomCxHelp2-data.eRad,eYHelp-data.eRad,
		data.atomCxHelp2+data.eRad,eYHelp+data.eRad,fill='red',
		outline='red')
	canvas.create_oval(data.Width/2-data.margin-data.eRad,eYHelp-data.eRad,
		data.Width/2-data.margin+data.eRad,eYHelp+data.eRad,
		fill=data.luckColor,outline=data.luckColor)
	canvas.create_oval(data.Width/2+data.margin-data.eRad,eYHelp-data.eRad,
		data.Width/2+data.margin+data.eRad,eYHelp+data.eRad,
		fill=data.fullColor,outline=data.fullColor)
	x0,y0=data.atomCxHelp1,eYHelp+data.margin
	canvas.create_text(x0,y0,text='Absorb this!',fill='white')
	x0=data.atomCxHelp2
	canvas.create_text(x0,y0,text='Block this!',fill='white')
	x0=data.Width/2
	canvas.create_text(x0,y0,text='Try them out!',fill='white')


def drawGuide(canvas,data):
	text1='Absorb appropriate electrons to make the atom grow bigger.'
	text2='Move the mouse to rotate the shields.'
	text3='(Tom, put Jerry down!)'
	text4,font='Press Space to pause.',('Helvetica',11)
	x0,y0=data.Width/2,data.atomCy+data.atomRadHelp*2+data.margin*4
	canvas.create_text(x0,y0,text=text1,fill='white',font=font)
	y0+=data.margin
	canvas.create_text(x0,y0,text=text2,fill='white',font=font)
	y0+=data.margin
	canvas.create_text(x0,y0,text=text3,fill='white',font=font)
	y0+=data.margin
	canvas.create_text(x0,y0,text=text4,fill='white',font=font)


def drawBackground(canvas,data):
	canvas.create_rectangle(0,0,data.Width,data.Height,fill=data.bgColor)


def drawHelp(canvas,data):
	drawBackground(canvas,data)
	drawButtonHelp(canvas,data)
	drawAtomHelp(canvas,data)
	drawShieldHelp(canvas,data)
	drawElectronHelp(canvas,data)
	drawGuide(canvas,data)


def timerFiredHelp(data,cnt=0):
	if cnt==len(data.shieldHelp1[0]): return
	data.shieldHelp1[0][cnt]+=1.5
	data.shieldHelp2[0][cnt]-=1.5
	cnt+=1
	timerFiredHelp(data,cnt)


def mousePressedHelp(event,data):
	if(data.backRx0<=event.x<=data.backRx1 and
		data.backRy0<=event.y<=data.backRy1):
		init(data)


def mouseMotionHelp(event,data):
	if(data.backRx0<=event.x<=data.backRx1 and
		data.backRy0<=event.y<=data.backRy1):
		data.backColor=data.atomColor
	else: data.backColor='white'


##################
# Level Choosing #
##################

def initLevel(data):
	data.EasyX0=data.Width/2-data.buttonWid/2-data.margin-data.buttonWid/2
	data.EasyY0=data.Height/2+data.buttonHeight*2
	data.easyRx0=data.EasyX0-data.buttonWid/2
	data.easyRy0=data.EasyY0-data.buttonHeight/2
	data.MedX0=data.EasyX0+data.buttonWid+data.margin
	data.medRx0=data.MedX0-data.buttonWid/2
	data.HardX0=data.MedX0+data.buttonWid+data.margin
	data.hardRx0=data.HardX0-data.buttonWid/2
	data.indivRy0=data.insaneRy0=data.easyRy0+data.buttonHeight+data.margin
	data.atomCyLevelTop=data.Height/2-data.margin*2
	data.atomCyLevelDown=data.indivRy0+data.buttonHeight*2+data.margin*2
	data.easyShieldLevel=deepcopy(data.easyShield)
	data.medShieldLevel=deepcopy(data.medShield)
	data.hardShieldLevel=deepcopy(data.hardShield)
	data.easyColor=data.medColor=data.hardColor=data.indivColor='white'
	data.insaneColor=data.saberColor='white'


def drawLevel(canvas,data):
	drawBackground(canvas,data)
	titleText,titleFont,x0,y0='Level',('Helvetica',25,'bold'),data.Width/2,150
	canvas.create_text(x0,y0,text=titleText,font=titleFont,
		anchor='center',fill='white')
	canvas.create_rectangle(data.backRx0,data.backRy0,data.backRx1,
		data.backRy1,fill=data.bgColor,outline=data.backColor,width=2)
	canvas.create_text(data.backRx0+data.buttonWid/2,
		data.backRy0+data.buttonHeight/2,text='Back',fill=data.backColor,
		font=data.intrFont)
	drawLevelButtonTop(canvas,data)
	drawLevelButtonDown(canvas,data)
	drawAtomLevelTop(canvas,data)
	drawAtomLevelDown(canvas,data)
	drawShieldLevelTop(canvas,data)
	drawShieldLevelDown(canvas,data)


def drawLevelButtonTop(canvas,data):
	# easy
	easyText,intrFont,x0,y0='Breeze',data.intrFont,data.EasyX0,data.EasyY0
	canvas.create_text(x0,y0,text=easyText,font=intrFont,fill=data.easyColor)
	canvas.create_rectangle(data.easyRx0,data.easyRy0,
		data.easyRx0+data.buttonWid,data.easyRy0+data.buttonHeight,
		width=2,outline=data.easyColor)
	# medium
	canvas.create_text(data.MedX0,y0,text='Dynamic',font=intrFont,
		fill=data.medColor)
	canvas.create_rectangle(data.medRx0,data.easyRy0,
		data.medRx0+data.buttonWid,data.easyRy0+data.buttonHeight,width=2,
		outline=data.medColor)
	# hard
	canvas.create_text(data.HardX0,y0,text='Adrenaline',font=intrFont,
		fill=data.hardColor)
	canvas.create_rectangle(data.hardRx0,data.easyRy0,
		data.hardRx0+data.buttonWid,data.easyRy0+data.buttonHeight,width=2,
		outline=data.hardColor)


def drawLevelButtonDown(canvas,data):
	# individual
	canvas.create_text(data.HardX0,data.indivRy0+data.buttonHeight/2,
		text='Individual',font=data.intrFont,fill=data.indivColor)
	canvas.create_rectangle(data.hardRx0,data.indivRy0,
		data.hardRx0+data.buttonWid,data.indivRy0+data.buttonHeight,
		width=2,outline=data.indivColor)
	# insane
	canvas.create_text(data.MedX0,data.insaneRy0+data.buttonHeight/2,
		text='Insane',font=data.intrFont,fill=data.insaneColor)
	canvas.create_rectangle(data.medRx0,data.insaneRy0,
		data.medRx0+data.buttonWid,data.insaneRy0+data.buttonHeight,
		width=2,outline=data.insaneColor)
	# saber
	canvas.create_text(data.EasyX0,data.indivRy0+data.buttonHeight/2,
		text='Jedi',font=data.intrFont,fill=data.saberColor)
	canvas.create_rectangle(data.easyRx0,data.insaneRy0,
		data.easyRx0+data.buttonWid,data.insaneRy0+data.buttonHeight,
		width=2,outline=data.saberColor)


def drawAtomLevelTop(canvas,data):
	canvas.create_oval(data.EasyX0-data.atomRadHelp,
		data.atomCyLevelTop-data.atomRadHelp,data.EasyX0+data.atomRadHelp,
		data.atomCyLevelTop+data.atomRadHelp,fill=data.atomColor,
		outline=data.atomColor)
	canvas.create_oval(data.MedX0-data.atomRadHelp,
		data.atomCyLevelTop-data.atomRadHelp,data.MedX0+data.atomRadHelp,
		data.atomCyLevelTop+data.atomRadHelp,fill=data.atomColor,
		outline=data.atomColor)
	canvas.create_oval(data.HardX0-data.atomRadHelp,
		data.atomCyLevelTop-data.atomRadHelp,data.HardX0+data.atomRadHelp,
		data.atomCyLevelTop+data.atomRadHelp,fill=data.atomColor,
		outline=data.atomColor)


def drawAtomLevelDown(canvas,data):
	canvas.create_oval(data.EasyX0-data.atomRad,
		data.atomCyLevelDown-data.atomRad,data.EasyX0+data.atomRad,
		data.atomCyLevelDown+data.atomRad,fill=data.atomColor,
		outline=data.atomColor)
	canvas.create_oval(data.HardX0-data.atomRadHelp,
		data.atomCyLevelDown-data.atomRadHelp,data.HardX0+data.atomRadHelp,
		data.atomCyLevelDown+data.atomRadHelp,fill=data.atomColor,
		outline=data.atomColor)


def drawShieldLevelTop(canvas,data):
	for i in range(len(data.easyShieldLevel[0])):
		canvas.create_arc(data.EasyX0-data.shieldRad,
			data.atomCyLevelTop-data.shieldRad,data.EasyX0+data.shieldRad,
			data.atomCyLevelTop+data.shieldRad,outline=data.atomColor,style=ARC,
			start=data.easyShieldLevel[0][i],extent=data.easyShieldLevel[1][i])
	for i in range(len(data.medShieldLevel[0])):
		canvas.create_arc(data.MedX0-data.shieldRad,
			data.atomCyLevelTop-data.shieldRad,data.MedX0+data.shieldRad,
			data.atomCyLevelTop+data.shieldRad,outline=data.atomColor,style=ARC,
			start=data.medShieldLevel[0][i],extent=data.medShieldLevel[1][i])
	for i in range(len(data.hardShieldLevel[0])):
		canvas.create_arc(data.HardX0-data.shieldRad,
			data.atomCyLevelTop-data.shieldRad,data.HardX0+data.shieldRad,
			data.atomCyLevelTop+data.shieldRad,outline=data.atomColor,style=ARC,
			start=data.hardShieldLevel[0][i],extent=data.hardShieldLevel[1][i])


def drawShieldLevelDown(canvas,data):
	canvas.create_arc(data.EasyX0-data.shieldRad,
		data.atomCyLevelDown-data.shieldRad,data.EasyX0+data.shieldRad,
		data.atomCyLevelDown+data.shieldRad,outline=data.atomColor,
		start=data.saberShield[0][0],extent=data.saberShield[1][0])
	canvas.create_arc(data.HardX0-data.shieldRad,
		data.atomCyLevelDown-data.shieldRad,data.HardX0+data.shieldRad,
		data.atomCyLevelDown+data.shieldRad,outline=data.atomColor,style=ARC,
		start=data.fullShield[0][0],extent=data.fullShield[1][0])


def rotateAntiClockLevelEasy(data,cnt=0):
	if cnt==len(data.easyShieldLevel[0]): return
	data.easyShieldLevel[0][cnt]+=1.5
	cnt+=1
	rotateAntiClockLevelEasy(data,cnt)


def rotateAntiClockLevelMed(data,cnt=0):
	if cnt==len(data.medShieldLevel[0]): return
	data.medShieldLevel[0][cnt]+=1.5
	cnt+=1
	rotateAntiClockLevelMed(data,cnt)


def rotateAntiClockLevelHard(data,cnt=0):
	if cnt==len(data.hardShieldLevel[0]): return
	data.hardShieldLevel[0][cnt]+=1.5
	cnt+=1
	rotateAntiClockLevelHard(data,cnt)


def rotateAntiClockLevelSaber(data,cnt=0):
	data.saberShield[0][0]+=1.5


def timerFiredLevel(data):
	rotateAntiClockLevelEasy(data)
	rotateAntiClockLevelMed(data)
	rotateAntiClockLevelHard(data)
	rotateAntiClockLevelSaber(data)


def saberOnSound():
	# code partially from
	# http://www.kosbie.net/cmu/fall-15/15-112/notes/notes-tkinter-demos.html
	# sound effect from
	# http://www.theforce.net/fanfilms/postproduction/soundfx/saberfx_fergo.asp
	sound="SabreOn.wav"
	flags = winsound.SND_FILENAME | winsound.SND_ASYNC
	winsound.PlaySound(sound,flags)


def mousePressedLevel(event,data):
	if data.easyRy0<=event.y<=data.easyRy0+data.buttonHeight:
		if data.easyRx0<=event.x<=data.easyRx0+data.buttonWid:
			initPlay(data)
			data.shield,data.gravityOn,data.mode=data.easyShield,False,'play'
		elif data.medRx0<=event.x<=data.medRx0+data.buttonWid:
			initPlay(data)
			data.shield,data.gravityOn,data.mode=data.medShield,False,'play'
		elif data.hardRx0<=event.x<=data.hardRx0+data.buttonWid:
			initPlay(data)
			data.shield,data.gravityOn,data.mode=data.hardShield,False,'play'
	if data.indivRy0<=event.y<=data.indivRy0+data.buttonHeight:
		if data.easyRx0<=event.x<=data.easyRx0+data.buttonWid:
			saberOnSound()
			initPlay(data)
			data.shield,data.gravityOn,data.mode=data.saberShield,False,'play'
		elif data.medRx0<=event.x<=data.medRx0+data.buttonWid:
			initPlay(data)
			data.shield,data.gravityOn,data.mode=data.insaneShield,True,'play'
		elif data.hardRx0<=event.x<=data.hardRx0+data.buttonWid:
			initDesign(data)
			data.mode='design'
	if(data.backRx0<=event.x<=data.backRx1 and
		data.backRy0<=event.y<=data.backRy1):
		init(data)


def mouseMotionLevel(event,data):
	if(data.backRx0<=event.x<=data.backRx1 and
		data.backRy0<=event.y<=data.backRy1): data.backColor=data.atomColor
	elif(data.easyRx0<=event.x<=data.easyRx0+data.buttonWid and
		data.easyRy0<=event.y<=data.easyRy0+data.buttonHeight):
		data.easyColor=data.atomColor
	elif(data.medRx0<=event.x<=data.medRx0+data.buttonWid and
		data.easyRy0<=event.y<=data.easyRy0+data.buttonHeight):
		data.medColor=data.atomColor
	elif(data.hardRx0<=event.x<=data.hardRx0+data.buttonWid and
		data.easyRy0<=event.y<=data.easyRy0+data.buttonHeight):
		data.hardColor=data.atomColor
	elif(data.hardRx0<=event.x<=data.hardRx0+data.buttonWid and
		data.indivRy0<=event.y<=data.indivRy0+data.buttonHeight):
		data.indivColor=data.atomColor
	elif(data.medRx0<=event.x<=data.medRx0+data.buttonWid and
		data.indivRy0<=event.y<=data.indivRy0+data.buttonHeight):
		data.insaneColor=data.atomColor
	elif(data.easyRx0<=event.x<=data.easyRx0+data.buttonWid and
		data.indivRy0<=event.y<=data.indivRy0+data.buttonHeight):
		data.saberColor=data.atomColor
	else: 
		data.backColor=data.easyColor=data.medColor=data.hardColor='white'
		data.indivColor=data.insaneColor=data.saberColor='white'


#################
# Design Shield #
#################

def initDesign(data):
	data.startDesignRx0=data.Width-data.backRx1
	data.shieldDesign=[[],[]]
	data.angleNeedleDesign=0
	data.angleShieldDesign=0
	data.makeShield=False
	data.resetRx0=data.Width/2-data.buttonWid/2
	data.resetRy0=data.backRy0
	data.resetColor='white'
	data.gravityRy0=data.Height/2+data.atomRadHelp+data.buttonHeight*2
	data.gravityOnColor='#%02x%02x%02x' %(0,240,64)
	data.gravityOffColor='#%02x%02x%02x' %(255,56,56)
	data.gravityOn,data.Gbutton=False,'Off'
	data.GbuttonColor=data.gravityOffColor


def drawAtomDesign(canvas,data):
	canvas.create_oval(data.Width/2-data.atomRadHelp,
		data.Height/2-data.atomRadHelp,data.Width/2+data.atomRadHelp,
		data.Height/2+data.atomRadHelp,fill=data.atomColor,
		outline=data.atomColor)


def drawButtonDesign(canvas,data):
	canvas.create_rectangle(data.backRx0,data.backRy0,data.backRx1,
		data.backRy1,width=2,outline=data.backColor)
	canvas.create_text(data.backRx0+data.buttonWid/2,
		data.backRy0+data.buttonHeight/2,text='Back',fill=data.backColor,
		font=data.intrFont)
	canvas.create_rectangle(data.startDesignRx0,data.backRy0,
		data.Width-data.backRx1+data.buttonWid,data.backRy1,
		width=2,outline=data.startColor)
	canvas.create_text(data.startDesignRx0+data.buttonWid/2,
		data.backRy0+data.buttonHeight/2,text='Start',font=data.intrFont,
		fill=data.startColor)
	canvas.create_rectangle(data.resetRx0,data.resetRy0,
		data.resetRx0+data.buttonWid,data.resetRy0+data.buttonHeight,
		width=2,outline=data.resetColor)
	canvas.create_text(data.resetRx0+data.buttonWid/2,
		data.resetRy0+data.buttonHeight/2,text='Reset',fill=data.resetColor,
		font=data.intrFont)
	canvas.create_rectangle(data.resetRx0,data.gravityRy0,
		data.resetRx0+data.buttonWid,data.gravityRy0+data.buttonHeight,
		width=2,fill=data.GbuttonColor,outline=data.GbuttonColor)
	canvas.create_text(data.resetRx0+data.buttonWid/2,
		data.gravityRy0+data.buttonHeight/2,text='Gravity '+data.Gbutton,
		fill='white',font=('Helvetica',15,'bold'))


def drawShieldDesign(canvas,data):
	for i in range(len(data.shieldDesign[0])):
		canvas.create_arc(data.Width/2-data.shieldRad,
			data.Height/2-data.shieldRad,data.Width/2+data.shieldRad,
			data.Height/2+data.shieldRad,start=data.shieldDesign[0][i],
			extent=data.shieldDesign[1][i],style=ARC,outline='white')


def drawNeedle(canvas,data):
	x=data.shieldRad*cos(data.angleNeedleDesign)+data.Width/2
	y=data.Height/2-data.shieldRad*sin(data.angleNeedleDesign)
	canvas.create_line(data.Width/2,data.Height/2,x,y,fill='white',width=2)


def drawDesignGuide(canvas,data):
	text1='Press Left key and Right key to rotate the needle.'
	text2,font='Press space to start/stop making the shield.',('Helvetica',10)
	x0,y0=data.Width/2,data.gravityRy0+data.margin*2+data.buttonHeight
	canvas.create_text(x0,y0,text=text1,fill='white',font=font)
	y0+=data.margin
	canvas.create_text(x0,y0,text=text2,fill='white',font=font)


def drawDesign(canvas,data):
	drawBackground(canvas,data)
	drawShieldDesign(canvas,data)
	drawNeedle(canvas,data)
	drawAtomDesign(canvas,data)
	drawButtonDesign(canvas,data)
	drawDesignGuide(canvas,data)


def mousePressedDesign(event,data):
	if(data.backRx0<=event.x<=data.backRx1 and
		data.backRy0<=event.y<=data.backRy1):
		initDesign(data)
		data.mode='level'
	if(data.resetRx0<=event.x<=data.resetRx0+data.buttonWid and
		data.resetRy0<=event.y<=data.resetRy0+data.buttonHeight):
		initDesign(data)
	if(data.startDesignRx0<=event.x<=data.startDesignRx0+data.buttonWid and
		data.backRy0<=event.y<=data.backRy1):
		data.shield=data.shieldDesign
		data.mode='play'
		data.paused=False
	if(data.resetRx0<=event.x<=data.resetRx0+data.buttonWid and
		data.gravityRy0<=event.y<=data.gravityRy0+data.buttonHeight):
		data.gravityOn=not data.gravityOn


def mouseMotionDesign(event,data):
	if(data.backRx0<=event.x<=data.backRx1 and
		data.backRy0<=event.y<=data.backRy1):
		data.backColor=data.atomColor
	elif(data.resetRx0<=event.x<=data.resetRx0+data.buttonWid and
		data.resetRy0<=event.y<=data.resetRy0+data.buttonHeight):
		data.resetColor=data.atomColor
	elif(data.startDesignRx0<=event.x<=data.startDesignRx0+data.buttonWid and
		data.resetRy0<=event.y<=data.resetRy0+data.buttonHeight):
		data.startColor=data.atomColor
	elif(data.resetRx0<=event.x<=data.resetRx0+data.buttonWid and
		data.gravityRy0<=event.y<=data.gravityRy0+data.buttonHeight):
		if not data.gravityOn: 
			data.Gbutton,data.GbuttonColor='On',data.gravityOnColor
		else: data.Gbutton,data.GbuttonColor='Off',data.gravityOffColor
	else: 
		data.backColor=data.resetColor=data.startColor='white'
		if not data.gravityOn:
			data.Gbutton,data.GbuttonColor='Off',data.gravityOffColor
		else: data.Gbutton,data.GbuttonColor='On',data.gravityOnColor


def keyPressedDesign(event,data):
	needleAngularVelo=0.05
	shieldAngularVelo=2.85
	if event.keysym=='Left': 
		data.angleNeedleDesign+=needleAngularVelo
		data.angleShieldDesign+=shieldAngularVelo
		if len(data.shieldDesign[0])!=0 and data.makeShield: 
			data.shieldDesign[1][-1]+=shieldAngularVelo
	if event.keysym=='Right':
		if data.angleNeedleDesign-needleAngularVelo>=0:
			data.angleNeedleDesign-=needleAngularVelo
		if data.angleShieldDesign-shieldAngularVelo>=0:
			data.angleShieldDesign-=shieldAngularVelo
			if len(data.shieldDesign[0])!=0 and data.makeShield: 
				data.shieldDesign[1][-1]-=shieldAngularVelo
	if event.keysym=='space': 
		if not data.makeShield:
			data.shieldDesign[0].append(data.angleShieldDesign)
			data.shieldDesign[1].append(0)
		data.makeShield=not data.makeShield


################
# Game Playing #
################

def initPlay(data):
	data.paused=False
	data.score=0
	data.bgColor='#%02x%02x%02x' %(28,105,133)
	data.atomCx,data.atomCy=data.Width/2,data.Height/2
	data.atomRad,data.atomColor=2,'cyan'
	data.shieldRad=50
	data.shield=None
	data.electrons=[]
	data.eRad=5
	data.electronPopLst=[]
	data.prevY=data.Height/2
	data.eLuck,data.luckTime=False,0
	data.fullShieldState,data.fullShieldTime=False,0
	data.prevShield=None
	data.shootFreqEasy=100
	data.gameOverColor='#%02x%02x%02x' %(255,20,60)


def drawAtom(canvas,data):
	x0,y0=data.atomCx-data.atomRad,data.atomCy-data.atomRad
	x1,y1=data.atomCx+data.atomRad,data.atomCy+data.atomRad
	canvas.create_oval(x0,y0,x1,y1,fill=data.atomColor,
		outline=data.atomColor)


def drawTime(canvas,data):
	x=data.backRx0+data.buttonWid/2
	canvas.create_text(x,data.backRy0+data.buttonHeight/2,
		text='Time: '+str(data.time//100),font=('Helvetica',10,'bold'),
		anchor='center',fill='white')


def drawScore(canvas,data):
	x=abs(data.Width-(data.backRx0+data.buttonWid/2))
	canvas.create_text(x,data.backRy0+data.buttonHeight/2,
		text='Score: '+str(data.score),font=('Helvetica',10,'bold'),
		anchor='center',fill='white')


def drawShield(canvas,data):
	if data.shield!=data.saberShield:
		for i in range(len(data.shield[0])):
			x0,y0=data.atomCx-data.shieldRad,data.atomCy-data.shieldRad
			x1,y1=data.atomCx+data.shieldRad,data.atomCy+data.shieldRad
			canvas.create_arc(x0,y0,x1,y1,start=data.shield[0][i],
				extent=data.shield[1][i],style=ARC,outline=data.atomColor)
	else:
		canvas.create_arc(data.atomCx-data.shieldRad,
			data.atomCy-data.shieldRad,data.atomCx+data.shieldRad,
			data.atomCy+data.shieldRad,start=data.shield[0][0],
			extent=data.shield[1][0],fill=data.atomColor,
			outline=data.atomColor)


def drawElectrons(canvas,data):
	for e in data.electrons:
		x0,y0=e[0]-data.eRad,e[1]-data.eRad
		x1,y1=e[0]+data.eRad,e[1]+data.eRad
		canvas.create_oval(x0,y0,x1,y1,fill=e[2],outline=e[2])


def drawPopElectron(canvas,data):
	popDelay=6
	for e in data.electronPopLst:
		x0,y0=e[0]-data.eRad,e[1]-data.eRad
		x1,y1=e[0]+data.eRad,e[1]+data.eRad
		if e[3]<=popDelay:
			canvas.create_oval(x0,y0,x1,y1,fill=data.bgColor,outline=e[2])


def drawButtons(canvas,data):
	canvas.create_rectangle(data.backRx0,data.backRy0,data.backRx1,
		data.backRy1,fill=data.bgColor,outline=data.backColor,width=2)
	canvas.create_text(data.backRx0+data.buttonWid/2,
		data.backRy0+data.buttonHeight/2,text='Back',font=data.intrFont,
		fill=data.backColor)
	canvas.create_rectangle(data.resetRx0,data.resetRy0,
		data.resetRx0+data.buttonWid,data.resetRy0+data.buttonHeight,
		fill=data.bgColor,outline=data.resetColor,width=2)
	canvas.create_text(data.resetRx0+data.buttonWid/2,
		data.resetRy0+data.buttonHeight/2,text='Reset',font=data.intrFont,
		fill=data.resetColor)


def mousePressedPlay(event,data):
	if(data.backRx0<=event.x<=data.backRx1 and
		data.backRy0<=event.y<=data.backRy1):
		data.mode='level'
	if(data.resetRx0<=event.x<=data.resetRx0+data.buttonWid and
		data.resetRy0<=event.y<=data.resetRy0+data.buttonHeight):
		prevShield,Gstate=data.shield,data.gravityOn
		initPlay(data)
		data.shield,data.gravityOn=prevShield,Gstate
		data.time,data.score=0,0
		# set shoot freq to default
		data.shootFreqEasy=100


def mouseMotionPlay(event,data):
	if(data.backRx0<=event.x<=data.backRx1 and
		data.backRy0<=event.y<=data.backRy1 and data.paused):
		data.backColor=data.atomColor
	elif(data.resetRx0<=event.x<=data.resetRx0+data.buttonWid and
		data.resetRy0<=event.y<=data.resetRy0+data.buttonHeight):
		data.resetColor=data.atomColor
	else: data.backColor=data.resetColor='white'
	if not data.paused:
		if event.y<data.prevY:
			if event.x>data.Width/2: rotateAntiClock(data)
			else: rotateClockwise(data)
		if event.y>data.prevY:
			if event.x>data.Width/2: rotateClockwise(data)
			else: rotateAntiClock(data)
	data.prevY=event.y


def keyPressedPlay(event,data):
	if event.keysym=='space': data.paused=not data.paused
	if not data.paused:
		if event.keysym=='Left': rotateAntiClock(data)
		if event.keysym=='Right': rotateClockwise(data)


def drawPlay(canvas,data):
	drawBackground(canvas,data)
	drawTime(canvas,data)
	drawScore(canvas,data)
	drawShield(canvas,data)
	drawAtom(canvas,data)
	drawElectrons(canvas,data)
	drawPopElectron(canvas,data)
	if data.paused: drawButtons(canvas,data)


def timerFiredPlay(data):
	# 800 and 1000 and 5 here are all milleseconds numbers
	if data.time%1000==0 and data.time!=0: data.shootFreqEasy-=5
	if data.eLuck: data.luckTime+=1
	if data.luckTime%800==0: data.luckTime,data.eLuck=0,False
	if data.fullShieldState: data.fullShieldTime+=1
	if data.fullShieldTime%1000==0 and data.fullShieldState:
		data.fullShieldTime,data.fullShieldState=0,False
		data.shield=deepcopy(data.prevShield)
	if not data.paused:
		data.time+=1
		shootElectron(data)
		if data.gravityOn: pullElectronGravity(data)
		if data.shield==data.easyShield: pullElectronEasy(data)
		else: pullElectronMedAndHard(data)
		abosrbElectron(data)
		updateElectron(data)
		if data.shield!=data.saberShield:blockElectron(data)
		else: blockElectronSaber(data)
		updatePopElectronTimer(data)


def shootElectron(data):
	# 5,80,90,120 are all timing numbers
	if data.shield==data.medShield: shootTimeDelay=90
	if data.shield==data.hardShield: shootTimeDelay=randint(80,120)
	else: shootTimeDelay=data.shootFreqEasy
	if data.time%shootTimeDelay==0:
		if data.time%(shootTimeDelay*5)==0: 
			color=choice([data.luckColor,data.fullColor])
		else: color=choice([data.atomColor,data.gameOverColor])
		if data.eLuck: color=data.atomColor
		side=choice(['up','down','left','right'])
		if side=='up': x0,y0=randint(0,data.Width),0
		elif side=='down': x0,y0=randint(0,data.Width),data.Height
		elif side=='left': x0,y0=0,randint(0,data.Height)
		elif side=='right': x0,y0=data.Width,randint(0,data.Height)
		# the 0 after color is a pop timer
		data.electrons.append([x0,y0,color,0,side])


def pullElectronEasy(data):
	accele=3
	for i in range(len(data.electrons)):
		x,y=data.electrons[i][0],data.electrons[i][1]
		rate=max(abs(x-data.atomCx),abs(y-data.atomCy))
		if rate!=0:
			veloX=abs(x-data.atomCx)/rate*accele
			veloY=abs(y-data.atomCy)/rate*accele
			if x>data.atomCx: data.electrons[i][0]-=veloX
			else: data.electrons[i][0]+=veloX
			if y>data.atomCy: data.electrons[i][1]-=veloY
			else: data.electrons[i][1]+=veloY


def pullElectronMedAndHard(data):
	accele=randint(2,5)
	for i in range(len(data.electrons)):
		x,y=data.electrons[i][0],data.electrons[i][1]
		rate=max(abs(x-data.atomCx),abs(y-data.atomCy))
		if rate!=0:
			veloX=abs(x-data.atomCx)/rate*accele
			veloY=abs(y-data.atomCy)/rate*accele
			if x>data.atomCx: data.electrons[i][0]-=veloX
			else: data.electrons[i][0]+=veloX
			if y>data.atomCy: data.electrons[i][1]-=veloY
			else: data.electrons[i][1]+=veloY


def pullElectronGravity(data):
	for i in range(len(data.electrons)):
		x,y=data.electrons[i][0],data.electrons[i][1]
		# Index 4 is the shooting side
		if data.electrons[i][4]=='left' or data.electrons[i][4]=='right':
			trajectoryLeftAndRight(data,i,x,y)
		else: trajectoryTopAndDown(data,i,x,y)


def trajectoryLeftAndRight(data,eIndex,x,y):
	rate=max(abs(x-data.atomCx),abs(y-data.atomCy))
	# times 3 to make electrons faster
	veloX=(x-data.atomCx)/rate*3
	# 60 is the time to reach the atom from side
	accele=(data.atomCy-y)/(60**2)
	veloY=0
	dist=sqrt((x-data.atomCx)**2+(y-data.atomCy)**2)
	if len(data.electrons[eIndex])==5: 
		data.electrons[eIndex].append(veloX)
		data.electrons[eIndex].append(veloY)
		data.electrons[eIndex].append(accele)
	else:
		data.electrons[eIndex][6]+=data.electrons[eIndex][7]
		data.electrons[eIndex][0]-=data.electrons[eIndex][5]
		data.electrons[eIndex][1]+=data.electrons[eIndex][6]


def trajectoryTopAndDown(data,eIndex,x,y):
	rate=max(abs(x-data.atomCx),abs(y-data.atomCy))
	# times 3 to make electrons faster
	veloY=(y-data.atomCy)/rate*3
	# 60 is the time to reach the atom from side
	accele=(data.atomCx-x)/(60**2)
	veloX=0
	dist=sqrt((x-data.atomCx)**2+(y-data.atomCy)**2)
	if len(data.electrons[eIndex])==5:
		data.electrons[eIndex].append(veloX)
		data.electrons[eIndex].append(veloY)
		data.electrons[eIndex].append(accele)
	else:
		data.electrons[eIndex][5]+=data.electrons[eIndex][7]
		data.electrons[eIndex][0]+=data.electrons[eIndex][5]
		data.electrons[eIndex][1]-=data.electrons[eIndex][6]


def abosrbElectron(data):
	for i in range(len(data.electrons)):
		x,y=data.electrons[i][0],data.electrons[i][1]
		dist=((x-data.atomCx)**2+(y-data.atomCy)**2)**0.5
		if dist<=data.atomRad:
			if data.electrons[i][2]==data.atomColor: 
				data.score+=1
				if data.shield!=data.saberShield: data.atomRad+=0.5
			if data.electrons[i][2]==data.gameOverColor:
				data.mode='gameOver'
				data.paused=True
			if data.electrons[i][2]==data.luckColor:
				data.eLuck=True
				if data.eLuck:
					for i in range(len(data.electrons)): 
						data.electrons[i][2]=data.atomColor
			if data.electrons[i][2]==data.fullColor:
				data.fullShieldState=True
				data.prevShield=deepcopy(data.shield)
				data.shield=deepcopy(data.fullShield)
			data.electronPopLst.append(deepcopy(data.electrons[i]))


def updatePopElectronTimer(data):
	# e[3] is a timer to determine pop up time
	for e in data.electronPopLst: e[3]+=1


def updateElectron(data):
	newLst=[]
	for e in data.electrons:
		if e not in data.electronPopLst:
			newLst.append(deepcopy(e))
	data.electrons=deepcopy(newLst)


def blockElectron(data):
	# 90,180,270 and 360 are angles in degree
	for e in data.electrons:
		x,y=e[0]-data.Width/2,data.Height/2-e[1]
		dist=sqrt(x**2+y**2)
		if x==0: attackAngle=90 if y<0 else 270
		if x<0: attackAngle=atan(y/x)*180/pi+180
		if x>0: attackAngle=atan(y/x)*180/pi
		if data.shieldRad-data.eRad*2<=dist<=(data.shieldRad+data.eRad*2):
			for i in range(len(data.shield[0])):
				pad=data.shield[0][i]
				if pad%360+data.shield[1][i]<=360:
					if pad%360<=attackAngle%360<=(pad+data.shield[1][i])%360:
						data.electronPopLst.append(e)
				else:
					if(pad%360<=attackAngle%360<=360 or
						0<=attackAngle%360<=(pad+data.shield[1][i])%360):
						data.electronPopLst.append(e)


def blockElectronSaber(data):
	# 90,180,270,360 are angles in degree
	for e in data.electrons:
		x,y=e[0]-data.Width/2,data.Height/2-e[1]
		dist=sqrt(x**2+y**2)
		if data.shieldRad-data.eRad*2<=dist<=data.shieldRad+data.eRad*2:
			pad=data.shield[0][0]
			if x==0: attackAngle=90 if y<0 else 270
			if x<0: attackAngle=atan(y/x)*180/pi+180
			if x>0: attackAngle=atan(y/x)*180/pi
			rad=data.eRad
			if(attackAngle-rad)%360<=pad%360<=(attackAngle+rad)%360:
				data.electronPopLst.append(e)


def rotateAntiClock(data,cnt=0):
	if cnt==len(data.shield[0]): return
	angularVelo=3
	data.shield[0][cnt]+=angularVelo
	cnt+=1
	rotateAntiClock(data,cnt)

def rotateClockwise(data,cnt=0):
	if cnt==len(data.shield[0]): return
	angularVelo=3
	data.shield[0][cnt]-=angularVelo
	cnt+=1
	rotateClockwise(data,cnt)


#############
# Game Over #
#############

def drawOverMsg(canvas,data):
	canvas.create_rectangle(0,data.Height/2-data.margin*2,
		data.Width,data.Height/2+data.margin*2,fill='crimson',
		outline=data.gameOverColor)
	canvas.create_text(data.Width/2,data.Height/2,text='Game Over',
		font=('Helvetica',25,'bold'))
	canvas.create_rectangle(data.backRx0,data.backRy0,data.backRx1,
		data.backRy1,fill=data.gameOverColor,outline=data.gameOverColor)
	canvas.create_text(data.backRx0+data.buttonWid/2,
		data.backRy0+data.buttonHeight/2,text='Start Again',font=data.intrFont)
	canvas.create_rectangle(data.resetRx0,data.resetRy0,
		data.resetRx0+data.buttonWid,data.resetRy0+data.buttonHeight,
		fill=data.gameOverColor,outline=data.gameOverColor)
	canvas.create_text(data.resetRx0+data.buttonWid/2,
		data.resetRy0+data.buttonHeight/2,text='Reset',font=data.intrFont)


def drawGameOver(canvas,data):
	drawBackground(canvas,data)
	drawScore(canvas,data)
	drawElectrons(canvas,data)
	drawOverMsg(canvas,data)


def mousePressedGameOver(event,data):
	if(data.backRx0<=event.x<=data.backRx1 and
		data.backRy0<=event.y<=data.backRy1):
		init(data)
	if(data.resetRx0<=event.x<=data.resetRx0+data.buttonWid and
		data.resetRy0<=event.y<=data.resetRy0+data.buttonHeight):
		prevShield=data.shield
		data.mode='play'
		data.shield=prevShield
	
###################
# Operation Funcs #
###################

def init(data):
	initSplash(data)
	initLevel(data)
	initPlay(data)
	initHelp(data)
	initDesign(data)


def mousePressed(event, data):
    if data.mode=='splash': mousePressedSplash(event,data)
    if data.mode=='level': mousePressedLevel(event,data)
    if data.mode=='help': mousePressedHelp(event,data)
    if data.mode=='gameOver': mousePressedGameOver(event,data)
    if data.mode=='design': mousePressedDesign(event,data)
    if data.mode=='play': mousePressedPlay(event,data)


def keyPressed(event, data):
	if data.mode=='design': keyPressedDesign(event,data)
	if data.mode=='play': keyPressedPlay(event,data)


def timerFired(data):
	if data.mode=='help': timerFiredHelp(data)
	if data.mode=='splash': timerFiredSplash(data)
	if data.mode=='level': timerFiredLevel(data)
	if data.mode=='play': timerFiredPlay(data)


def redrawAll(canvas, data):
    if data.mode=='splash': drawSplash(canvas,data)
    if data.mode=='level': drawLevel(canvas,data)
    if data.mode=='play': drawPlay(canvas,data)
    if data.mode=='help': drawHelp(canvas,data)
    if data.mode=='gameOver': drawGameOver(canvas,data)
    if data.mode=='design': drawDesign(canvas,data)


def mouseMotion(event,data):
	if data.mode=='splash': mouseMotionSplash(event,data)
	if data.mode=='help': mouseMotionHelp(event,data)
	if data.mode=='level': mouseMotionLevel(event,data)
	if data.mode=='design': mouseMotionDesign(event,data)
	if data.mode=='play': mouseMotionPlay(event,data)


#################
# Main Run Func #
#################

def Elementure(width=300, height=300):
    def redrawAllWrapper(canvas, data):
        canvas.delete(ALL)
        redrawAll(canvas, data)
        canvas.update()    

    def mousePressedWrapper(event, canvas, data):
        mousePressed(event, data)
        redrawAllWrapper(canvas, data)

    def mouseMotionWrapper(event,canvas,data):
    	mouseMotion(event,data)
    	redrawAllWrapper(canvas,data)

    def keyPressedWrapper(event, canvas, data):
        keyPressed(event, data)
        redrawAllWrapper(canvas, data)

    def timerFiredWrapper(canvas, data):
        timerFired(data)
        redrawAllWrapper(canvas, data)
        # pause, then call timerFired again
        canvas.after(data.timerDelay, timerFiredWrapper, canvas, data)
    class Struct(): pass
    data=Struct()
    data.Width = width
    data.Height = height
    data.timerDelay = 10 # milliseconds
    data.time=0
    init(data)
    root = Tk()
    canvas = Canvas(root, width=data.Width, height=data.Height)
    canvas.pack()
    # set up events
    root.bind("<Button-1>", lambda event:
                            mousePressedWrapper(event, canvas, data))
    root.bind("<Key>", lambda event:
                            keyPressedWrapper(event, canvas, data))
    root.bind("<Motion>", lambda event: 
    						mouseMotionWrapper(event,canvas,data))
    timerFiredWrapper(canvas, data)
    # and launch the app
    root.mainloop()

Elementure(500, 650)